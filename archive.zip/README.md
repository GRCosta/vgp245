# VGP 245 Python Programming

Welcome to the Python Programming git hub page.  The code here is for the class to follow along the lecture
